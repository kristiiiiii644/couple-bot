import aiosqlite

DB_PATH = "couple_bot.db"

async def get_db():
    db = await aiosqlite.connect(DB_PATH)
    db.row_factory = aiosqlite.Row
    return db

async def init_db():
    db = await get_db()
    await db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            partner_id INTEGER,
            gender TEXT
        );
        CREATE TABLE IF NOT EXISTS cycles (
            user_id INTEGER PRIMARY KEY,
            last_period_date TEXT,
            cycle_length INTEGER DEFAULT 28
        );
        CREATE TABLE IF NOT EXISTS goals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT,
            category TEXT,
            created_by INTEGER,
            status TEXT DEFAULT 'active',
            deadline TEXT,
            reward TEXT
        );
        CREATE TABLE IF NOT EXISTS wishes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT,
            link TEXT,
            price INTEGER,
            shop TEXT,
            created_by INTEGER,
            status TEXT DEFAULT 'available',
            reserved_by INTEGER
        );
        CREATE TABLE IF NOT EXISTS savings (
            goal_name TEXT,
            total_goal INTEGER,
            current_amount INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS contributions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount INTEGER,
            comment TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)
    await db.commit()
    await db.close()

async def add_user(user_id, username, gender=None):
    db = await get_db()
    await db.execute(
        "INSERT OR REPLACE INTO users (user_id, username, gender) VALUES (?, ?, ?)",
        (user_id, username, gender)
    )
    await db.commit()
    await db.close()

async def set_partner(user_id, partner_id):
    db = await get_db()
    await db.execute("UPDATE users SET partner_id = ? WHERE user_id = ?", (partner_id, user_id))
    await db.commit()
    await db.close()

async def get_user(user_id):
    db = await get_db()
    cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = await cursor.fetchone()
    await db.close()
    return user

async def set_last_period(user_id, date_str):
    db = await get_db()
    await db.execute(
        "INSERT OR REPLACE INTO cycles (user_id, last_period_date, cycle_length) VALUES (?, ?, 28)",
        (user_id, date_str)
    )
    await db.commit()
    await db.close()

async def get_cycle(user_id):
    db = await get_db()
    cursor = await db.execute("SELECT * FROM cycles WHERE user_id = ?", (user_id,))
    cycle = await cursor.fetchone()
    await db.close()
    return cycle

async def add_goal(user_id, text, category, deadline, reward):
    db = await get_db()
    await db.execute(
        "INSERT INTO goals (text, category, created_by, deadline, reward) VALUES (?, ?, ?, ?, ?)",
        (text, category, user_id, deadline, reward)
    )
    await db.commit()
    await db.close()

async def get_goals():
    db = await get_db()
    cursor = await db.execute("SELECT * FROM goals ORDER BY id DESC")
    goals = await cursor.fetchall()
    await db.close()
    return goals

async def complete_goal(goal_id):
    db = await get_db()
    await db.execute("UPDATE goals SET status = 'done' WHERE id = ?", (goal_id,))
    await db.commit()
    await db.close()

async def add_wish(user_id, text, link, price, shop):
    db = await get_db()
    await db.execute(
        "INSERT INTO wishes (text, link, price, shop, created_by) VALUES (?, ?, ?, ?, ?)",
        (text, link, price, shop, user_id)
    )
    await db.commit()
    await db.close()

async def get_wishes():
    db = await get_db()
    cursor = await db.execute("SELECT * FROM wishes ORDER BY id DESC")
    wishes = await cursor.fetchall()
    await db.close()
    return wishes

async def reserve_wish(wish_id, user_id):
    db = await get_db()
    await db.execute(
        "UPDATE wishes SET status = 'reserved', reserved_by = ? WHERE id = ?",
        (user_id, wish_id)
    )
    await db.commit()
    await db.close()

async def init_savings(name, total):
    db = await get_db()
    await db.execute(
        "INSERT OR REPLACE INTO savings (goal_name, total_goal, current_amount) VALUES (?, ?, 0)",
        (name, total)
    )
    await db.commit()
    await db.close()

async def get_savings():
    db = await get_db()
    cursor = await db.execute("SELECT * FROM savings LIMIT 1")
    row = await cursor.fetchone()
    await db.close()
    return row

async def update_savings(amount):
    db = await get_db()
    await db.execute("UPDATE savings SET current_amount = current_amount + ?", (amount,))
    await db.commit()
    await db.close()

async def add_contribution(user_id, amount, comment):
    db = await get_db()
    await db.execute(
        "INSERT INTO contributions (user_id, amount, comment) VALUES (?, ?, ?)",
        (user_id, amount, comment)
    )
    await db.commit()
    await db.close()