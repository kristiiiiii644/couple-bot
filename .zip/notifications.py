import asyncio
import aioschedule
from datetime import date
from aiogram import Bot
from database import get_db

PHASES = {
    "menstrual": {
        "emoji": "🩸",
        "name": "Менструальная фаза",
        "days": (1, 5),
        "for_her": "Сегодня день отдыха и заботы о себе. Больше спи, пей тёплый чай, никакого спорта.",
        "for_him": "🩸 Период заботы. Захвати её любимый шоколад, предложи заказать ужин. Не напрягай."
    },
    "follicular": {
        "emoji": "🌱",
        "name": "Фолликулярная фаза",
        "days": (6, 12),
        "for_her": "Энергия растёт! Отличный день для спортзала, новых проектов и встреч с друзьями.",
        "for_him": "🌱 Она полна сил! Предложи активный отдых: велопрогулку, танцы, поход."
    },
    "ovulation": {
        "emoji": "🔥",
        "name": "Овуляция",
        "days": (13, 16),
        "for_her": "Пик привлекательности и энергии! Лучший день для свидания и флирта.",
        "for_him": "🔥 Сегодня ты ей особенно интересен. Уверенность — твой козырь."
    },
    "luteal": {
        "emoji": "🍂",
        "name": "Лютеиновая фаза (ПМС)",
        "days": (17, 28),
        "for_her": "Время ПМС. Побалуй себя: магний, тёплая ванна, любимый сериал.",
        "for_him": "🍂 Режим повышенной нежности. Не спорь, принеси вкусняшку, обними."
    }
}

def calculate_phase(last_period_date: date, cycle_length: int = 28):
    today = date.today()
    days_passed = (today - last_period_date).days % cycle_length
    cycle_day = days_passed + 1
    
    for phase_key, phase_data in PHASES.items():
        start, end = phase_data["days"]
        if start <= cycle_day <= end:
            return phase_key, phase_data, cycle_day
    
    return None, None, None

async def get_all_users_with_cycles():
    db = await get_db()
    cursor = await db.execute("""
        SELECT u.user_id, u.partner_id, u.gender, c.last_period_date, c.cycle_length 
        FROM users u 
        JOIN cycles c ON u.user_id = c.user_id 
        WHERE u.gender = 'female'
    """)
    rows = await cursor.fetchall()
    await db.close()
    return rows

async def get_savings_progress():
    db = await get_db()
    cursor = await db.execute("SELECT * FROM savings LIMIT 1")
    row = await cursor.fetchone()
    await db.close()
    if row:
        _, total, current = row
        percent = int((current / total) * 100) if total > 0 else 0
        return total, current, percent
    return None, None, None

async def send_daily_notifications(bot: Bot):
    print("📢 Отправка ежедневных уведомлений...")
    
    users = await get_all_users_with_cycles()
    
    for user in users:
        user_id, partner_id, gender, last_period_str, cycle_length = user
        
        try:
            last_period = date.fromisoformat(last_period_str)
            phase_key, phase_data, cycle_day = calculate_phase(last_period, cycle_length)
            
            if phase_data:
                her_text = f"🌸 <b>Доброе утро!</b> День цикла: {cycle_day}\n"
                her_text += f"{phase_data['emoji']} <b>{phase_data['name']}</b>\n\n"
                her_text += f"💁‍♀️ {phase_data['for_her']}"
                
                await bot.send_message(user_id, her_text, parse_mode="HTML")
                
                if partner_id:
                    him_text = f"☀️ <b>Доброе утро!</b>\n"
                    him_text += f"🌸 Партнёрша сегодня в фазе: {phase_data['emoji']} <b>{phase_data['name']}</b>\n\n"
                    him_text += f"💡 {phase_data['for_him']}"
                    
                    await bot.send_message(partner_id, him_text, parse_mode="HTML")
        
        except Exception as e:
            print(f"Ошибка отправки пользователю {user_id}: {e}")
    
    if date.today().weekday() == 0:
        total, current, percent = await get_savings_progress()
        if total:
            db = await get_db()
            cursor = await db.execute("SELECT user_id, partner_id FROM users WHERE partner_id IS NOT NULL LIMIT 1")
            row = await cursor.fetchone()
            await db.close()
            
            if row:
                text = f"🐷 <b>Прогресс копилки за неделю:</b>\n"
                text += f"Собрано: {current:,} из {total:,} руб. ({percent}%)\n"
                text += f"Осталось: {total - current:,} руб."
                
                await bot.send_message(row[0], text, parse_mode="HTML")
                if row[1]:
                    await bot.send_message(row[1], text, parse_mode="HTML")

async def scheduler(bot: Bot):
    aioschedule.every().day.at("10:00").do(send_daily_notifications, bot=bot)
    
    while True:
        await aioschedule.run_pending()
        await asyncio.sleep(60)

async def start_scheduler(bot: Bot):
    asyncio.create_task(scheduler(bot))