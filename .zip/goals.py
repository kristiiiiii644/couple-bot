from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from database import add_goal, get_goals, complete_goal, get_user

router = Router()

@router.message(F.text == "🎯 Наши цели")
async def goals_menu(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 Список целей", callback_data="list_goals")],
        [InlineKeyboardButton(text="➕ Добавить цель", callback_data="add_goal")]
    ])
    await message.answer("Раздел целей:", reply_markup=kb)

@router.callback_query(F.data == "add_goal")
async def ask_goal_text(callback: CallbackQuery):
    await callback.message.answer(
        "Напиши цель в формате:\n"
        "<i>Текст цели | категория | Дедлайн (ГГГГ-ММ-ДД) | награда</i>\n\n"
        "Пример: Сходить в театр | month | 2026-07-20 | ужин в ресторане\n\n"
        "Категории: month, year, global",
        parse_mode="HTML"
    )
    await callback.answer()

@router.message(F.text.contains("|"))
async def add_goal_handler(message: Message):
    parts = [p.strip() for p in message.text.split("|")]
    if len(parts) < 2:
        await message.answer("Неверный формат. Нужно минимум: текст | категория")
        return
    
    text = parts[0]
    category = parts[1] if len(parts) > 1 else "month"
    deadline = parts[2] if len(parts) > 2 else None
    reward = parts[3] if len(parts) > 3 else None
    
    await add_goal(message.from_user.id, text, category, deadline, reward)
    await message.answer(f"✅ Цель добавлена: <b>{text}</b>", parse_mode="HTML")
    
    user = await get_user(message.from_user.id)
    if user and user[2]:
        try:
            await message.bot.send_message(
                user[2],
                f"🎯 Новая общая цель от партнёра: <b>{text}</b>",
                parse_mode="HTML"
            )
        except:
            pass

@router.callback_query(F.data == "list_goals")
async def show_goals(callback: CallbackQuery):
    goals = await get_goals()
    if not goals:
        await callback.message.answer("Пока нет общих целей.")
        await callback.answer()
        return
    
    text = "<b>🎯 Наши цели:</b>\n\n"
    kb_list = []
    
    for goal in goals:
        status_icon = "✅" if goal[4] == 'done' else "⬜"
        text += f"{status_icon} <b>{goal[1]}</b> ({goal[2]})\n"
        if goal[4] != 'done':
            kb_list.append([InlineKeyboardButton(
                text=f"✅ Выполнить: {goal[1][:30]}",
                callback_data=f"done_goal_{goal[0]}"
            )])
    
    kb = InlineKeyboardMarkup(inline_keyboard=kb_list) if kb_list else None
    await callback.message.answer(text, parse_mode="HTML", reply_markup=kb)
    await callback.answer()

@router.callback_query(F.data.startswith("done_goal_"))
async def mark_goal_done(callback: CallbackQuery):
    goal_id = int(callback.data.split("_")[2])
    await complete_goal(goal_id)
    
    user = await get_user(callback.from_user.id)
    if user and user[2]:
        try:
            await callback.bot.send_message(user[2], "🎉 Партнёр выполнил общую цель! Жди награду 😊")
        except:
            pass
    
    await callback.message.answer("✅ Цель отмечена как выполненная!")
    await callback.answer()