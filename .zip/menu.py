from aiogram import Router, F
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.filters import Command

router = Router()

def main_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🎯 Наши цели"), KeyboardButton(text="✨ Хотелки")],
            [KeyboardButton(text="🐷 Копилка"), KeyboardButton(text="🌸 Мой цикл")]
        ],
        resize_keyboard=True
    )

@router.message(Command("menu"))
@router.message(F.text.lower() == "меню")
async def show_menu(message: Message):
    await message.answer("Главное меню:", reply_markup=main_menu())