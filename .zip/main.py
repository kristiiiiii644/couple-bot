import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from config import BOT_TOKEN
from notifications import start_scheduler
from database import init_db
import start, menu, cycle, goals, wishes, savings

logging.basicConfig(level=logging.INFO)

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

async def main():
    await init_db()
    
    dp.include_routers(
        start.router,
        menu.router,
        cycle.router,
        goals.router,
        wishes.router,
        savings.router
    )
    
    # Убрали delete_webhook и start_scheduler
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())