from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.filters import Command
from database import add_user, set_partner, get_user

router = Router()

@router.message(Command("start"))
async def start_cmd(message: Message):
    user_id = message.from_user.id
    username = message.from_user.username or "Аноним"
    
    await add_user(user_id, username)
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🙋‍♀️ Девушка", callback_data="gender_female")],
        [InlineKeyboardButton(text="🙋‍♂️ Парень", callback_data="gender_male")]
    ])
    await message.answer(f"Привет, {username}! Выбери пол:", reply_markup=kb)

@router.callback_query(F.data.startswith("gender_"))
async def choose_gender(callback: CallbackQuery):
    user_id = callback.from_user.id
    gender = callback.data.split("_")[1]
    
    await add_user(user_id, callback.from_user.username, gender)
    
    await callback.message.edit_text(
        f"Пол выбран: {'👩 Девушка' if gender == 'female' else '👨 Парень'}\n\n"
        "Теперь привяжите партнёра!\n"
        "Отправь партнёру команду:\n/link {твой user_id}\n\n"
        f"Твой ID: <code>{user_id}</code>",
        parse_mode="HTML"
    )
    await callback.answer()

@router.message(Command("link"))
async def link_partner(message: Message):
    args = message.text.split()
    if len(args) != 2:
        await message.answer("Использование: /link ID_партнёра")
        return
    
    try:
        partner_id = int(args[1])
    except:
        await message.answer("ID должен быть числом")
        return
    
    user_id = message.from_user.id
    
    await set_partner(user_id, partner_id)
    await set_partner(partner_id, user_id)
    
    await message.answer("✅ Вы связаны! Введите /menu")
    await message.bot.send_message(partner_id, "✅ Ваш партнёр подключился! Напиши /menu")