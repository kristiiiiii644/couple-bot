from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import add_wish, get_wishes, reserve_wish

router = Router()

@router.message(F.text == "✨ Хотелки")
async def wishes_menu(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 Смотреть хотелки", callback_data="list_wishes")],
        [InlineKeyboardButton(text="➕ Добавить", callback_data="add_wish")]
    ])
    await message.answer("Раздел хотелок:", reply_markup=kb)

@router.callback_query(F.data == "add_wish")
async def ask_wish(callback: CallbackQuery):
    await callback.message.answer(
        "Напиши хотелку в формате:\n"
        "<i>Название | ссылка | цена | магазин</i>\n\n"
        "Пример: Платье Zara | https://zara.com | 5000 | Zara",
        parse_mode="HTML"
    )
    await callback.answer()

@router.message(F.text.contains("|"))
async def add_wish_handler(message: Message):
    parts = [p.strip() for p in message.text.split("|")]
    if len(parts) < 1:
        return
    
    text = parts[0]
    link = parts[1] if len(parts) > 1 else None
    price = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None
    shop = parts[3] if len(parts) > 3 else None
    
    await add_wish(message.from_user.id, text, link, price, shop)
    await message.answer(f"✅ Хотелка добавлена: <b>{text}</b>", parse_mode="HTML")

@router.callback_query(F.data == "list_wishes")
async def show_wishes(callback: CallbackQuery):
    wishes = await get_wishes()
    if not wishes:
        await callback.message.answer("Список хотелок пуст.")
        await callback.answer()
        return
    
    text = "<b>✨ Наши хотелки:</b>\n\n"
    kb_list = []
    
    for wish in wishes:
        if wish[6] == 'available':
            text += f"🎁 <b>{wish[1]}</b>\n"
            if wish[3]: text += f"  💰 {wish[3]} руб.\n"
            text += "\n"
            kb_list.append([InlineKeyboardButton(
                text=f"🎁 Хочу подарить: {wish[1][:25]}",
                callback_data=f"reserve_{wish[0]}"
            )])
    
    kb = InlineKeyboardMarkup(inline_keyboard=kb_list) if kb_list else None
    await callback.message.answer(text, parse_mode="HTML", reply_markup=kb)
    await callback.answer()

@router.callback_query(F.data.startswith("reserve_"))
async def reserve_wish_handler(callback: CallbackQuery):
    wish_id = int(callback.data.split("_")[1])
    await reserve_wish(wish_id, callback.from_user.id)
    await callback.message.answer("🤫 Хотелка зарезервирована! Партнёр не узнает.")
    await callback.answer()