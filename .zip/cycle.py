from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from datetime import date
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import database

router = Router()

PHASES = {
    "menstrual": {
        "emoji": "🩸", "name": "Менструальная фаза", "days": (1, 5),
        "for_her": "Время отдыха и заботы о себе. Больше спи, пей тёплый чай.",
        "for_him": "Будь заботливым. Предложи заказать еду, посмотреть фильм под пледиком."
    },
    "follicular": {
        "emoji": "🌱", "name": "Фолликулярная фаза", "days": (6, 12),
        "for_her": "Энергия растёт! Отличное время для спортзала и новых проектов.",
        "for_him": "Она полна энергии. Предложи активный отдых!"
    },
    "ovulation": {
        "emoji": "🔥", "name": "Овуляция", "days": (13, 16),
        "for_her": "Пик привлекательности! Идеальное время для свидания!",
        "for_him": "Ты ей особенно интересен. Будь уверен в себе."
    },
    "luteal": {
        "emoji": "🍂", "name": "Лютеиновая фаза", "days": (17, 28),
        "for_her": "Может появиться ПМС. Больше отдыхай, магний в помощь.",
        "for_him": "Режим нежности. Купи её любимый шоколад и не спорь по пустякам."
    }
}

def calculate_phase(last_period_date: date, cycle_length: int = 28):
    today = date.today()
    days_passed = (today - last_period_date).days % cycle_length
    cycle_day = days_passed + 1
    for phase_key, phase_data in PHASES.items():
        start, end = phase_data["days"]
        if start <= cycle_day <= end:
            return phase_key, phase_data, cycle_day
    return None, None, None

@router.message(F.text == "🌸 Мой цикл")
async def cycle_menu(message: Message):
    user = await database.get_user(message.from_user.id)
    if not user or user[3] != 'female':
        await message.answer("Этот раздел доступен только девушке.")
        return
    
    cycle = await database.get_cycle(message.from_user.id)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📅 Указать дату последних М", callback_data="set_period")],
        [InlineKeyboardButton(text="📊 Моя фаза сейчас", callback_data="show_phase")]
    ])
    if cycle:
        await message.answer(f"Последние М: {cycle[1]}\nДлина цикла: {cycle[2]} дней", reply_markup=kb)
    else:
        await message.answer("Данные о цикле не указаны.", reply_markup=kb)

@router.callback_query(F.data == "show_phase")
async def show_current_phase(callback: CallbackQuery):
    user_id = callback.from_user.id
    user = await database.get_user(user_id)
    cycle = await database.get_cycle(user_id)
    if not cycle:
        await callback.message.answer("Сначала укажите дату последних месячных.")
        await callback.answer()
        return
    last_period = date.fromisoformat(cycle[1])
    phase_key, phase_data, day = calculate_phase(last_period, cycle[2])
    if not phase_data:
        await callback.answer("Ошибка расчёта.")
        return
    text = f"{phase_data['emoji']} <b>{phase_data['name']}</b>\nДень цикла: {day}\n\n💁‍♀️ <b>Для тебя:</b> {phase_data['for_her']}"
    await callback.message.answer(text, parse_mode="HTML")
    partner_id = user[2]
    if partner_id:
        him_text = f"🌸 <b>Фаза партнёрши:</b> {phase_data['emoji']} {phase_data['name']}\n\n💡 <b>Совет:</b> {phase_data['for_him']}"
        try:
            await callback.bot.send_message(partner_id, him_text, parse_mode="HTML")
        except:
            pass
    await callback.answer()

@router.callback_query(F.data == "set_period")
async def ask_period_date(callback: CallbackQuery):
    await callback.message.answer("Введи дату начала последних месячных в формате ГГГГ-ММ-ДД\nНапример: 2026-06-15")
    await callback.answer()

@router.message(F.text.regexp(r"\d{4}-\d{2}-\d{2}"))
async def set_period_date(message: Message):
    user = await database.get_user(message.from_user.id)
    if not user or user[3] != 'female':
        return
    try:
        last_period = date.fromisoformat(message.text)
        await database.set_last_period(message.from_user.id, str(last_period))
        await message.answer(f"✅ Дата последних месячных: {message.text}")
    except:
        await message.answer("❌ Неверный формат даты.")