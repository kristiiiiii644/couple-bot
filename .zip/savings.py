from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from database import get_savings, update_savings, add_contribution, init_savings

router = Router()

@router.message(F.text == "🐷 Копилка")
async def savings_menu(message: Message):
    savings = await get_savings()
    if not savings:
        await message.answer(
            "Копилка пуста. Напиши цель накоплений в формате:\n"
            "<i>Название | сумма</i>\n"
            "Пример: Отпуск | 100000",
            parse_mode="HTML"
        )
        return
    
    goal_name, total, current = savings
    percent = int((current / total) * 100) if total > 0 else 0
    bar = "█" * (percent // 10) + "░" * (10 - percent // 10)
    
    text = f"🐷 <b>Копим на: {goal_name}</b>\n"
    text += f"[{bar}] {percent}%\n"
    text += f"Собрано: {current:,} руб. из {total:,} руб.\n"
    text += f"Осталось: {total - current:,} руб."
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💰 Внести деньги", callback_data="add_money")]
    ])
    
    await message.answer(text, parse_mode="HTML", reply_markup=kb)

@router.message(F.text.contains("|"))
async def init_savings_handler(message: Message):
    parts = [p.strip() for p in message.text.split("|")]
    if len(parts) == 2 and parts[1].isdigit():
        name = parts[0]
        total = int(parts[1])
        await init_savings(name, total)
        await message.answer(f"✅ Копилка создана: <b>{name}</b>, цель: {total:,} руб.", parse_mode="HTML")

@router.callback_query(F.data == "add_money")
async def ask_amount(callback: CallbackQuery):
    await callback.message.answer("Напиши сумму и комментарий:\n<i>сумма комментарий</i>\nПример: 5000 премия", parse_mode="HTML")
    await callback.answer()

@router.message(F.text.regexp(r"^\d+"))
async def add_money_handler(message: Message):
    parts = message.text.split(maxsplit=1)
    amount = int(parts[0])
    comment = parts[1] if len(parts) > 1 else ""
    
    await add_contribution(message.from_user.id, amount, comment)
    await update_savings(amount)
    
    savings = await get_savings()
    if savings:
        _, total, current = savings
        percent = int((current / total) * 100)
        await message.answer(f"✅ Добавлено: +{amount:,} руб. | Прогресс: {percent}%")